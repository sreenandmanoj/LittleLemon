## APIs routes
Backend developer capstone project - By Daniel
  * **/auth/** -> Djoser basic URLs & Auth token rouutes related
  * **/menu/** -> Menu API routes
  * **/restaurant/booking/** -> Booking API

